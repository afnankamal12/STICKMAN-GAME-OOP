
import javax.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;


public class Road extends JPanel implements ActionListener {

    public  Road(){
        mainTimer.start();
        addKeyListener(new myKeyAdapter());
        setFocusable(true);
}
    Image img = new ImageIcon (filename:"res/roadbackground.jpg").getImage();
    StickPlayer sp = new StickPlayer()
    Timer mainTimer = new Timer (dela 20, this);

    public void paint (Graphics g){

        g =(Graphics2D) g;
        g.drawImage(img, sp.layer1, 0; null);
        g.drawImage(sp.img, sp.x, sp.y, null);
        g.drawImage(img, sp.layer2, 0, null);
}
    public void actionPerformed(ActionListener e){
        p.move();
        repaint();


    }
    private class myKeyAdapter extends KeyAdapter{

        public void keyPressed (KeyEvent e){
            sp.keyPressed(e);
        }
        public void keyreleased(KeyEvent e){
            sp.kewReleased(e);
        }
}

}