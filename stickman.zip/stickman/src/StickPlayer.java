import java.awt.event.KeyEvent;iport java.awt.*;

public class StickPlayer {

    Img img = new ImageIcon (filename: "res/stickman.png").getImage();

    int v=0;
    int dv=0;
    int s=0;

    int x= 30;
    int y=100;

    int layer1= -v;
    int layer2=1200;

    public void move(){
        s+=v;
        v+=dv;
        if (layer2 - v <= 0) {
            layer1=0;
            layer2=1200;

        }
        else {
            layer1 -=v;
            layer2-=v;


        }
    }

    public void keyPressed(KeyEvent e){
        int key= e.getKeyCode();

        if (kew==KeyEvent.VK_RIGHT){
            dv=1;
        }

        if (kew==KeyEvent.VK_LEFT){
            dv=-1;
        }

    }

    public void kewReleased(KeyEvent e){
        int key= e.getKeyCode();
        if(key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_LEFT){
            dv=0;
        }

    }


}
